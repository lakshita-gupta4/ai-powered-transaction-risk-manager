import os
import joblib
import numpy as np
import pandas as pd
import streamlit as st

MODEL_PATH = "model/risk_model.joblib"

st.set_page_config(
    page_title="AI Transaction Risk Manager",
    page_icon="🛡️",
    layout="wide"
)

st.title("🛡️ AI-Powered Transaction Risk Manager")
st.caption("Educational/demo system for transaction risk assessment")

if not os.path.exists(MODEL_PATH):
    st.error("Model not found. Run: python generate_data.py && python train_model.py")
    st.stop()

artifact = joblib.load(MODEL_PATH)
pipeline = artifact["pipeline"]
features = artifact["features"]
thresholds = artifact["thresholds"]

def risk_label(probability):
    if probability >= thresholds["high"]:
        return "HIGH RISK"
    if probability >= thresholds["medium"]:
        return "MEDIUM RISK"
    return "LOW RISK"

def explain_risk(row):
    reasons = []

    if row["amount"] > 500:
        reasons.append("High transaction amount")
    if row["is_international"] == 1:
        reasons.append("International transaction")
    if row["is_new_device"] == 1:
        reasons.append("New device detected")
    if row["failed_attempts"] >= 2:
        reasons.append("Multiple failed attempts")
    if row["transactions_24h"] >= 8:
        reasons.append("Unusually high transaction frequency")
    if row["distance_from_usual_km"] > 150:
        reasons.append("Large distance from usual transaction location")
    if row["hour"] <= 4 or row["hour"] >= 23:
        reasons.append("Transaction made at an unusual hour")
    if row["account_age_days"] < 30:
        reasons.append("New account")

    return reasons or ["No major risk indicator detected"]

def predict(df):
    X = df[features]
    probabilities = pipeline.predict_proba(X)[:, 1]
    result = df.copy()
    result["risk_probability"] = probabilities
    result["risk_level"] = [risk_label(p) for p in probabilities]
    return result

tab1, tab2 = st.tabs(["🔎 Single Transaction", "📁 Batch Analysis"])

with tab1:
    st.subheader("Analyze a transaction")

    col1, col2, col3 = st.columns(3)

    with col1:
        amount = st.number_input("Transaction amount", min_value=1.0, value=250.0, step=10.0)
        hour = st.slider("Transaction hour", 0, 23, 14)
        distance = st.number_input(
            "Distance from usual location (km)",
            min_value=0.0,
            value=20.0,
            step=1.0
        )

    with col2:
        account_age = st.number_input(
            "Account age (days)",
            min_value=1,
            value=365,
            step=1
        )
        transactions_24h = st.number_input(
            "Transactions in last 24 hours",
            min_value=0,
            value=3,
            step=1
        )
        failed_attempts = st.number_input(
            "Failed attempts",
            min_value=0,
            value=0,
            step=1
        )

    with col3:
        is_international = st.selectbox(
            "International transaction",
            ["No", "Yes"]
        )
        is_new_device = st.selectbox(
            "New device",
            ["No", "Yes"]
        )

    if st.button("Analyze Risk", type="primary", use_container_width=True):
        transaction = pd.DataFrame([{
            "amount": amount,
            "hour": hour,
            "distance_from_usual_km": distance,
            "account_age_days": account_age,
            "transactions_24h": transactions_24h,
            "failed_attempts": failed_attempts,
            "is_international": int(is_international == "Yes"),
            "is_new_device": int(is_new_device == "Yes"),
        }])

        probability = float(pipeline.predict_proba(transaction[features])[0, 1])
        label = risk_label(probability)

        st.metric("Risk Probability", f"{probability * 100:.1f}%")
        st.subheader(f"Assessment: {label}")

        st.write("### Risk Factors")
        for reason in explain_risk(transaction.iloc[0]):
            st.write(f"- {reason}")

        st.progress(min(probability, 1.0))

with tab2:
    st.subheader("Batch CSV analysis")
    st.write(
        "Upload a CSV containing the model features: "
        + ", ".join(features)
    )

    uploaded = st.file_uploader("Upload transactions CSV", type=["csv"])

    if uploaded:
        batch = pd.read_csv(uploaded)
        missing = [f for f in features if f not in batch.columns]

        if missing:
            st.error("Missing columns: " + ", ".join(missing))
        else:
            result = predict(batch)

            high = int((result["risk_level"] == "HIGH RISK").sum())
            medium = int((result["risk_level"] == "MEDIUM RISK").sum())
            low = int((result["risk_level"] == "LOW RISK").sum())

            c1, c2, c3 = st.columns(3)
            c1.metric("High Risk", high)
            c2.metric("Medium Risk", medium)
            c3.metric("Low Risk", low)

            st.dataframe(result, use_container_width=True)

            csv = result.to_csv(index=False).encode("utf-8")
            st.download_button(
                "Download Risk Report",
                csv,
                "risk_report.csv",
                "text/csv"
            )

st.divider()
st.caption(
    "Demo only: this project uses synthetic data and should not be used "
    "for real financial or credit decisions."
)
