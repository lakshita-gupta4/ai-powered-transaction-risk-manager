# AI-Powered Transaction Risk Manager

An end-to-end machine-learning project that predicts transaction risk and presents the result through a Streamlit dashboard.

## Features
- Synthetic transaction dataset generation
- Logistic Regression fraud-risk model
- Risk probability and Low/Medium/High classification
- Explainable risk factors
- Streamlit dashboard
- Batch CSV prediction
- Model evaluation metrics

## Tech Stack
Python, Pandas, NumPy, Scikit-learn, Streamlit, Joblib

## Project Structure
```text
ai-transaction-risk-manager/
├── app.py
├── train_model.py
├── generate_data.py
├── requirements.txt
├── README.md
├── .gitignore
├── data/
│   └── transactions.csv
└── model/
    └── risk_model.joblib
```

## Run Locally

```bash
pip install -r requirements.txt
python generate_data.py
python train_model.py
streamlit run app.py
```

Then open the Streamlit URL shown in the terminal.

## Important
The included dataset is synthetic and is intended for learning/demo purposes. It must not be treated as a production fraud-detection model or used for real financial decisions.
